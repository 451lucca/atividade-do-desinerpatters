# atividade-do-desinerpatters
aaaaaaaaaaa
