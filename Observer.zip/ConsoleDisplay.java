public class ConsoleDisplay implements WeatherObserver {
    @Override
    public void update(double temperature) {
        System.out.println("Display: temperatura atual = " + temperature + "C");
    }
}
