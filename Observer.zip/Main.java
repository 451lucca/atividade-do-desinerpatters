public class Main {
    public static void main(String[] args) {
        WeatherStation station = new WeatherStation();

        station.addObserver(new ConsoleDisplay());
        station.addObserver(new FanController());

        station.setTemperature(22);
        station.setTemperature(28);
    }
}
