public class FanController implements WeatherObserver {
    @Override
    public void update(double temperature) {
        if (temperature >= 25) {
            System.out.println("Ventilador: ligado");
        } else {
            System.out.println("Ventilador: desligado");
        }
    }
}
